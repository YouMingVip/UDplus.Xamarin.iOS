﻿using System;
using ObjCRuntime;
namespace UDplus.Xamarin.iOS
{
[Native]
public enum eScenarioType : long
{
	Normal = 0,
	Game = 1,
	Dplus = 4	}
}
